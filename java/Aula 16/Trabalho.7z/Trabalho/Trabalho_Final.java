public class Trabalho_Final {
  public static void main (String args[]) {
    
      int [] vet = new int [1];
      int num=0,op1=0,op2=0,op3=0,result=0;
      vet = numero (vet);
      if (num >=0 && num<=99999){
      op1 = (num*2 + 6);
      op2 = (op1/2);
      op3 = op2 - num;
      result = op3;
      }
      
      System.out.println("O RESULTADO FINAL �:"+result);
      System.out.println("#######################################################");
      System.out.println("O RESULTADO DO N�MERO GERADO SEMPRE SER� 3!!!");
      System.out.println("Explica��o: se o n�mero gerado � x: (2x+6)/2 - x = 3");   
      System.out.println("#######################################################");
      System.out.println();
    }
    
    public static int [] numero (int[] n) {
      int c;
      for (c = 0; c < 1; c ++) {
      n [c] = (int) ((Math.random () * 100) + 1);
      System.out.println("#######################################################");
      System.out.println("O N�MERO GERADO ALEAT�RIAMENTE �:"+n[c]);
      System.out.println("#######################################################");
      }
      return n;
    }
  }
  
  
  
  
  
  
  
